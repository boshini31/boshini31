import java.util.*;
import java.util.logging.*;

public class ScheduleManager {
    private static ScheduleManager instance;
    private List<Task> tasks = new ArrayList<>();
    private List<TaskObserver> observers = new ArrayList<>();
    private static final Logger logger = Logger.getLogger(ScheduleManager.class.getName());

    private ScheduleManager() {
        try {
            FileHandler fh = new FileHandler("schedule_manager.log", true);
            logger.addHandler(fh);
            SimpleFormatter formatter = new SimpleFormatter();
            fh.setFormatter(formatter);
        } catch (Exception e) {
            logger.warning("Failed to initialize logging.");
        }
    }

    public static ScheduleManager getInstance() {
        if (instance == null) {
            synchronized (ScheduleManager.class) {
                if (instance == null) {
                    instance = new ScheduleManager();
                }
            }
        }
        return instance;
    }

    public void addTask(Task task) {
        for (Task existingTask : tasks) {
            if (isOverlapping(task, existingTask)) {
                notifyObservers(task, existingTask);
                logger.warning("Task conflict detected: " + task.getDescription() + " conflicts with " + existingTask.getDescription());
                System.out.println("Error: Task conflicts with existing task \"" + existingTask.getDescription() + "\"");
                return;
            }
        }
        tasks.add(task);
        tasks.sort(Comparator.comparing(Task::getStartTime));
        logger.info("Task added: " + task.getDescription());
        System.out.println("Task added successfully. No conflicts.");
    }

    public void removeTask(String description) {
        Task taskToRemove = null;
        for (Task task : tasks) {
            if (task.getDescription().equalsIgnoreCase(description)) {
                taskToRemove = task;
                break;
            }
        }
        if (taskToRemove != null) {
            tasks.remove(taskToRemove);
            logger.info("Task removed: " + description);
            System.out.println("Task removed successfully.");
        } else {
            logger.warning("Task not found: " + description);
            System.out.println("Error: Task not found.");
        }
    }

    public void viewTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks scheduled for the day.");
        } else {
            for (Task task : tasks) {
                System.out.println(task);
            }
        }
    }

    public void addObserver(TaskObserver observer) {
        observers.add(observer);
    }

    private boolean isOverlapping(Task t1, Task t2) {
        return t1.getStartTime().compareTo(t2.getEndTime()) < 0 && t2.getStartTime().compareTo(t1.getEndTime()) < 0;
    }

    private void notifyObservers(Task newTask, Task existingTask) {
        for (TaskObserver observer : observers) {
            observer.onTaskConflict(newTask, existingTask);
        }
    }
}
