public interface TaskObserver {
    void onTaskConflict(Task newTask, Task existingTask);
}
